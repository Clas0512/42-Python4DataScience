# ft_package

`ft_package` is a Python package that provides utility functions. One of the key functions in this package is `count_in_list`, which counts the occurrences of a specific element in a list.

## Installation

You can install the package via [PyPI](https://pypi.org/) once it is published:

```bash
pip install ft_package
